function transmission = rayleighTransmission(Z_, Pressure, Lam)
    % Calculate Rayleigh transmission using Eq (3) in Gueymard (2019).
    %
    % Parameters:
    %   Z_ (double): The zenith angle in degrees.
    %   Pressure (double): The pressure in mbar.
    %   Lam (double array): Wavelength array in nm.
    %
    % Returns:
    %   transmission (double array): The calculated transmission values (0-1).
    %
    % Example:
    %   Lam = transmission.utils.make_wavelength_array();
    %   Trans = transmission.atmospheric.rayleigh(30, 1013.25, Lam);
    
    % Calculate airmass using SMARTS coefficients for Rayleigh scattering
    import transmission.utils.airmassFromSMARTS
    Am_ = airmassFromSMARTS(Z_, 'rayleigh');
    
    % Convert wavelength from nm to micrometers
    Lam_um = Lam ./ 1000;
    
    % Calculate normalized pressure
    Pressure_norm = Pressure ./ 1013.25;
    
    % Calculate Rayleigh optical depth using Gueymard (2019) formula
    Tau_rayleigh = Pressure_norm ./ (117.3405 .* Lam_um.^4 - ...
                                     1.5107 .* Lam_um.^2 + ...
                                     0.017535 - 8.7743e-4 ./ Lam_um.^2);
    
    % Calculate transmission and clip to [0,1]
    transmission = exp(-Am_ .* Tau_rayleigh);
    transmission = max(0, min(1, transmission));
end