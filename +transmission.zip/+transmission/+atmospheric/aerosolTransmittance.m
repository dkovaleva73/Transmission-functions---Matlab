function transmission = aerosolTransmittance(Z_, Tau_aod500, Alpha, Lam)
    % Calculate aerosol transmission including airmass effects.
    %
    % Parameters:
    %   Z_ (double): The zenith angle in degrees.
    %   Tau_aod500 (double): The aerosol optical depth at 500nm.
    %   Alpha (double): The Angstrom exponent.
    %   Lam (double array): Wavelength array in nm.
    %
    % Returns:
    %   transmission (double array): The calculated transmission values (0-1).
    %
    % Example:
    %   Lam = transmission.utils.make_wavelength_array();
    %   Trans = transmission.atmospheric.aerosol(45, 0.1, 1.3, Lam);
    
    % Calculate airmass using SMARTS coefficients for aerosol
    import transmission.utils.airmassFromSMARTS
    Am_ = airmassFromSMARTS(Z_, 'aerosol');
    
    % Calculate optical depth using power law
    % Tau_lambda = Tau_500 * (lambda/500)^(-Alpha)
    Tau_lambda = Tau_aod500 * (Lam ./ 500).^(-Alpha);
    
    % Calculate transmission and clip to [0,1]
    transmission = exp(-Am_ .* Tau_lambda);
    transmission = max(0, min(1, transmission));
end