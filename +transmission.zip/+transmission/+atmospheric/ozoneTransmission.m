function transmission = ozoneTransmission(Z_, Dobson_units, Lam)
    % Calculate ozone transmission.
    %
    % Parameters:
    %   Z_ (double): The zenith angle in degrees.
    %   Dobson_units (double): The ozone column in Dobson units.
    %   Lam (double array): Wavelength array in nm.
    %
    % Returns:
    %   transmission (double array): The calculated transmission values (0-1).
    %
    % Example:
    %   Lam = transmission.utils.make_wavelength_array(280, 400, 121);
    %   Trans = transmission.atmospheric.ozone(30, 300, Lam);
    
    % Constants
    NLOSCHMIDT = 2.6867811e19;  % cm-3, Loschmidt number
    
    % Convert Dobson units to atm-cm
    Ozone_atm_cm = Dobson_units * 0.001;
    
    % Try multiple possible locations for ozone data file
    Possible_paths = {
        '/home/dana/matlab/data_Transmission_Fitter/Templates/Abs_O3UV.dat', ...
        '/home/dana/Documents/MATLAB/inwork/data/Templates/Abs_O3UV.dat', ...
        '/home/dana/anaconda3/lib/python3.12/site-packages/transmission_fitter/data/Templates/Abs_O3UV.dat', ...
        '../data_Transmission_Fitter/Templates/Abs_O3UV.dat'
    };
    
    Data_file = '';
    for I = 1:length(Possible_paths)
        if exist(Possible_paths{I}, 'file')
            Data_file = Possible_paths{I};
            break;
        end
    end
    
    if isempty(Data_file)
        error('Ozone data file (Abs_O3UV.dat) not found in any expected location');
    end
    
    % Read ozone absorption data (skip header, use first two columns)
    Data = readtable(Data_file, 'Delimiter', '\t', 'ReadVariableNames', true);
    Abs_wavelength = Data.Wvl_nm;
    Ozone_cross_section = Data.Ref_228K;
    
    % Interpolate ozone cross-sections to wavelength array
    Ozone_xs_interp = interp1(Abs_wavelength, Ozone_cross_section, Lam, 'linear', 0);
    
    % Calculate absorption coefficient
    Absorption_coeff = NLOSCHMIDT * Ozone_xs_interp;
    
    % Calculate airmass using SMARTS coefficients for ozone
    import transmission.utils.airmassFromSMARTS
    Am_ = airmassFromSMARTS(Z_, 'o3');
    
    % Calculate optical depth
    Tau_ozone = Absorption_coeff * Ozone_atm_cm;
    
    % Calculate transmission and clip to [0,1]
    transmission = exp(-Am_ .* Tau_ozone);
    transmission = max(0, min(1, transmission));
end