function Lam = makeWavelengthArray(Min_wvl, Max_wvl, Num_points)
    % Generate wavelength array for photometric calculations
    %
    % Parameters:
    %   Min_wvl (double): Minimum wavelength in nm (default: 300)
    %   Max_wvl (double): Maximum wavelength in nm (default: 1100)  
    %   Num_points (int): Number of points (default: 401)
    %
    % Returns:
    %   Lam (double array): Wavelength array in nm
    %
    % Notes:
    %   Num_points = 401 points mimics Gaia sampling (dLambda = 2nm)
    %   Num_points = 81 points gives dLambda = 10nm 
    %
    % Example:
    %   Lam = transmission.utils.make_wavelength_array();
    %   Lam_coarse = transmission.utils.make_wavelength_array(400, 800, 81);

    arguments
        Min_wvl (1,1) double = 300.0
        Max_wvl (1,1) double = 1100.0
        Num_points (1,1) double = 401
    end
    
    Lam = linspace(Min_wvl, Max_wvl, Num_points);
end